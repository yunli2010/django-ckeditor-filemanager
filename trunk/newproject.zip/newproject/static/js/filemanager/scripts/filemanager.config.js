/*---------------------------------------------------------
  Configuration
---------------------------------------------------------*/

// Set this to the server side language you wish to use.
var lang = 'py'; // options: lasso, php, py

// Set this to the directory you wish to manage.
var fileRoot = '/static/upload/';

// Show image previews in grid views?
var showThumbs = true;

var django_view = '../../../filemanager_connectors/';